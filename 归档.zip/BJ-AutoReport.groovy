//autoreport bak
//cmd chcp 65001
import java.util.Calendar;
pipeline {
    agent any
    environment {
        DATETIME_TAG = java.time.LocalDateTime.now()
        DATE_TAG = java.time.LocalDate.now()
        TIME_TAG = java.time.LocalTime.now().withNano(0)
        timestamp = Calendar.getInstance().getTimeInMillis();
        timetime = Calendar.getInstance().getTimeInMillis();
        
        
    }
    stages {
        stage('init') {
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
					bat encoding: 'UTF-8',label: 'delete_previous_failure_flag', returnStdout: true, script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.fail (del /s /q E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.fail)"
                    bat encoding: 'UTF-8',label: 'makedirs', script: """if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\CI\\  (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\CI\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\CI_Bool\\  (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\CI_Bool\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\ATS\\  (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\ATS\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\ATC\\  (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\ATC\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\SYDB\\  (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\SYDB\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\Design\\  (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\Design\\ 
                    )                   
                    
                    """                 
                    loginfo = readFile 'C:\\K2JEN\\tools\\cclogin.ini'
                    user = loginfo.tokenize()[0]
                    pass = loginfo.tokenize()[1]

                    bat encoding: 'UTF-8',label: 'login', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT"   
                    sleep 5                   
   
                }
            }
        }    
        stage('FetchCI'){
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("Baseline_CI")){
                        
                        timetime = Calendar.getInstance().getTimeInMillis();                      
                        bat encoding: 'UTF-8',label: 'FetchCI', script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v REPORT_CI_${timestamp} -s ${CCURL} -b ${prop2.Baseline_CI} \"${prop[index][4]}\""
                        sleep 10
                        string11 = "cd \"REPORT_CI_${timestamp}${prop[index][4]}\""    
                        print("${string11}")
						bat encoding: 'UTF-8',label: 'PackCI', returnStdout: true, script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_CI}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.Lable_CI}.zip C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_CI}&&rmdir /s /q C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_CI}\\&&move /Y ${prop2.Lable_CI}.zip E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\CI\\"                        
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmCI-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_CI_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmCI-F', returnStdout: true, script: "if exist REPORT_CI_${timestamp} rmdir /s /q REPORT_CI_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                }
            }            
        }
        stage('FetchCIBOOL'){
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("Baseline_CI_Bool")){
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchCI-bool', script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v REPORT_CIBOOL_${timestamp} -s ${CCURL} -b ${prop2.Baseline_CI_Bool} \"${prop[index][9]}\""
                        sleep 10
                        
                        string11 = "cd \"REPORT_CIBOOL_${timestamp}${prop[index][9]}\""                     
                        bat encoding: 'UTF-8',label: 'PackCI-bool', returnStdout: true, script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_CI}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.Lable_CI}.zip C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_CI}&&rmdir /s /q C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_CI}\\&&move /Y ${prop2.Lable_CI}.zip E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\CI_Bool\\"
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmCI-bool-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_CIBOOL_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmCI-bool-F', returnStdout: true, script: "if exist REPORT_CIBOOL_${timestamp} rmdir /s /q REPORT_CIBOOL_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                }
            }            
        }
        stage('FetchATS'){
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("Baseline_ATS")){
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchATS', script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v REPORT_ATS_${timestamp} -s ${CCURL} -b ${prop2.Baseline_ATS} \"${prop[index][5]}\""
                        sleep 10
                        string11 = "cd \"REPORT_ATS_${timestamp}${prop[index][5]}\""    
                        bat encoding: 'UTF-8',label: 'PackATS', returnStdout: true, script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_ATS}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.Lable_ATS}.zip C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_ATS}&&rmdir /s /q C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_ATS}\\&&move /Y ${prop2.Lable_ATS}.zip E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\ATS\\"
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmATS-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_ATS_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmATS-F', returnStdout: true, script: "if exist REPORT_ATS_${timestamp} rmdir /s /q REPORT_ATS_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                    
                }
            }            
        }
        stage('FetchATC'){
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("Baseline_ATC")){
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchATC', script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v REPORT_ATC_${timestamp} -s ${CCURL} -b ${prop2.Baseline_ATC} \"${prop[index][6]}\""
                        sleep 10
                        string11 = "cd \"REPORT_ATC_${timestamp}${prop[index][6]}\""  
                        bat encoding: 'UTF-8',label: 'PackATC', returnStdout: true, script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_ATC}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.Lable_ATC}.zip C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_ATC}&&rmdir /s /q C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_ATC}\\&&move /Y ${prop2.Lable_ATC}.zip E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\ATC\\"
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmATC-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_ATC_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmATC-F', returnStdout: true, script: "if exist REPORT_ATC_${timestamp} rmdir /s /q REPORT_ATC_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                }
            }            
        }

        stage('FetchSYDB'){
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("Baseline_SYDB")){
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchSYDB', script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v REPORT_SYDB_${timestamp} -s ${CCURL} -b ${prop2.Baseline_SYDB} \"${prop[index][8]}\""
                        sleep 30
                        string11 = "cd \"REPORT_SYDB_${timestamp}${prop[index][8]}\""  
                        bat encoding: 'UTF-8',label: 'PackSYDB', returnStdout: true, script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_SYDB}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.Lable_SYDB}.zip C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_SYDB}&&rmdir /s /q C:\\K2JEN\\TEMP\\RT\\${prop2.Lable_SYDB}\\&&move /Y ${prop2.Lable_SYDB}.zip E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\SYDB\\"
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmSYDB-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_SYDB_${timestamp} "
                        sleep 5
                        bat encoding: 'UTF-8',label: 'rmSYDB-F', returnStdout: true, script: "if exist REPORT_SYDB_${timestamp} rmdir /s /q REPORT_SYDB_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }                    

                }
            }            
        }
        stage('FetchDESIGN'){
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjWholeName){
                            index = i
                            break
                        }
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("Baseline_Design")){
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchDesign', script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v REPORT_Design_${timestamp} -s ${CCURL} -b ${prop2.Baseline_Design} \"${prop[index][7]}\""
                        sleep 10
                        string11 = "cd \"REPORT_Design_${timestamp}${prop[index][7]}\"" 
                        bat encoding: 'UTF-8',label: 'PackDesign', returnStdout: true, script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\RT\\${prop2.Baseline_Design}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.Baseline_Design}.zip C:\\K2JEN\\TEMP\\RT\\${prop2.Baseline_Design}&&rmdir /s /q C:\\K2JEN\\TEMP\\RT\\${prop2.Baseline_Design}\\&&move /Y ${prop2.Baseline_Design}.zip E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}\\Design\\"
                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmDesign-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_Design_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmDesign-F', returnStdout: true, script: "if exist REPORT_Design_${timestamp} rmdir /s /q REPORT_Design_${timestamp} "                     

                    }
                    else{
                        print('No Need')
                    }
                }
            }            
        }
    }
    post {
        success {
            script {
                bat encoding: 'UTF-8',label: 'Remove_para_file', returnStdout: true, script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt (del /s /q E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt)"
            }
        }
        failure {
            script {
                bat encoding: 'UTF-8',label: 'Create_failure_flag', returnStdout: true, script: "echo fail>E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.fail"
                //bat encoding: 'UTF-8',label: 'Remove_para_file', returnStdout: true, script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt (del /s /q E:\\FIVP_Tools\\FIVP_Tools\\ReportAnalysis\\${Name}.txt)"
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'login', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT"   
                sleep 5
                    
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmCI-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_CI_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmCI-F', returnStdout: true, script: "if exist REPORT_CI_${timestamp} rmdir /s /q REPORT_CI_${timestamp}" 
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmCI-bool-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_CIBOOL_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmCI-bool-F', returnStdout: true, script: "if exist REPORT_CIBOOL_${timestamp} rmdir /s /q REPORT_CIBOOL_${timestamp}" 
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATS-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_ATS_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmATS-F', returnStdout: true, script: "if exist REPORT_ATS_${timestamp} rmdir /s /q REPORT_ATS_${timestamp}" 
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATC-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_ATC_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmATC-F', returnStdout: true, script: "if exist REPORT_ATC_${timestamp} rmdir /s /q REPORT_ATC_${timestamp}" 
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmSYDB-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_SYDB_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmSYDB-F', returnStdout: true, script: "if exist REPORT_SYDB_${timestamp} rmdir /s /q REPORT_SYDB_${timestamp}"  
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmDesign-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v REPORT_Design_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmDesign-F', returnStdout: true, script: "if exist REPORT_Design_${timestamp} rmdir /s /q REPORT_Design_${timestamp}"  
                
            }
        }
    }
}
