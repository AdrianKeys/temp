//autoABSwitch bak
//cmd chcp 65001
import java.util.Calendar;
pipeline {
    agent any
    environment {
        DATETIME_TAG = java.time.LocalDateTime.now()
        DATE_TAG = java.time.LocalDate.now()
        TIME_TAG = java.time.LocalTime.now().withNano(0)
        timestamp = Calendar.getInstance().getTimeInMillis();
        timetime = Calendar.getInstance().getTimeInMillis();
        ifEmail = true
        
        
        Calendar cal = Calendar.getInstance();
        Month1 = cal.get(Calendar.MONTH);
        Year = cal.get(Calendar.YEAR);
        intMonth = Integer.parseInt("${Month1}")
        Month = String.valueOf(intMonth+1)
        logname = 'C:\\FIVP_Tools\\'+"${Year}"+'-'+"${Month}"+'-AB.log'
    }
    stages {
        stage('init') {
            steps {
                script {
                    String stime = java.time.LocalDateTime.now()
                    print("${Time}_${PC}_${Proj}.json")
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----start-----${stime}>>${logname}"

                    bat encoding: 'UTF-8',label: 'cleanworkspace',  script: "del /S /Q  \"${WORKSPACE}\\*.*\""
                    bat encoding: 'UTF-8',label: 'del mssver', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c \"del /s /q C:\\AB\\mssver.txt 2>nul\""
                        
                    bat encoding: 'UTF-8',label: 'chcp',  script: "chcp"
                    
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    print("${Time}_${PC}_${Proj}.json")
                    print(index)
                    print(prop[index][0])
                    print(prop[index][1])
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----PROJ-----${prop[index][1]}>>${logname}"
                    // if (prop2.containsKey("DVCOM")){
                        // DVCOM=prop2.DVCOM                        
                    // } else {
                        // DVCOM='0'                        
                    // }
                    FetchMSS = false
                    emailstring=""
                    for (int i=0; i<prop2.Email.size(); i++){
                        emailstring=emailstring+prop2.Email[i]+","                       
                    }
                    //print(emailstring)
                    print(prop2.K2NO)
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----K2NO-----${prop2.K2NO}>>${logname}"
                    if (ifEmail=="true") {
                        emailext (
                        body: """
                            <html>    
                                <head>    
                                    <meta charset="UTF-8">    
                                    <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                                </head>                          
                                <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                    <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                        <tr>    
                                            本邮件由系统自动发出，无需回复<br/>            
                                            以下为${prop2.K2NO[0]} ${prop2.K2NO[1]} 双机测试任务信息</br>                                          
                                        </tr>    
                                        <tr>    
                                            <td><br/>    
                                            <b><font color="#0B610B">任务信息</font></b>    
                                            <hr size="2" width="100%" align="center" /></td>    
                                        </tr>    
                                        <tr>    
                                            <td>    
                                                <ul>    
                                                    <li>项目名称 ： ${prop[index][1]}</li> 
                                                    <li>任务发起 ： ${PC}</li>
                                                    <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>                                                   
                                                    <li>触发原因 ： \${CAUSE}</li>                                                       
                                                    <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                    <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                    <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                    <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                    <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                       
                                                </ul>         
                                            </td>                                         
                                        </tr>    
                                    </table>    
                                </body>    
                            </html>  
                        """, 
                        subject: "[系统自动发送][双机测试开始]${PC}发起的${prop[index][1]}项目, ${prop2.K2NO[0]} ${prop2.K2NO[1]},流程开始", 
                        from: "FIVPServer@casco.com.cn",
                        to: "${emailstring}"
                        )
                    }
                    
                    CCloc = prop[index][2]
                    print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
					bat encoding: 'UTF-8',label: 'makedirs',  script: """if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\CI\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\CI\\
                    )
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\ATS\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\ATS\\
                    )
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\DESIGN\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\DESIGN\\
                    )
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\MSS\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\MSS\\
                    )
                    """
                    loginfo = readFile 'C:\\K2JEN\\tools\\cclogin.ini'
                    user = loginfo.tokenize()[0]
                    pass = loginfo.tokenize()[1]
                    bat encoding: 'UTF-8',label: 'login',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch"
                    sleep 5
                }
            }
        }
        stage('FetchCI'){

            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    CCloc = prop[index][2]
                    // print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("CIBaseline")){
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchCI',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ABSwitch_CI_${timestamp} -s ${CCURL} -b ${prop2.CIBaseline} \"${prop[index][4]}\""
                        sleep 10
                        string11 = "cd \"ABSwitch_CI_${timestamp}${prop[index][4]}\""
                        print("${string11}")
						bat encoding: 'UTF-8',label: 'PackCI',  script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\AB\\${prop2.CIDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.CIDV}.zip C:\\K2JEN\\TEMP\\AB\\${prop2.CIDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\AB\\${prop2.CIDV}\\&&move /Y ${prop2.CIDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\CI\\"

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmCI-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_CI_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmCI-F',  script: "if exist ABSwitch_CI_${timestamp} rmdir /s /q ABSwitch_CI_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                }
            }
        }
        
        stage('FetchATS'){

            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    CCloc = prop[index][2]
                    // print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("ATSBaseline")){

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchATS',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ABSwitch_ATS_${timestamp} -s ${CCURL} -b ${prop2.ATSBaseline} \"${prop[index][5]}\""
                        sleep 10
                        string11 = "cd \"ABSwitch_ATS_${timestamp}${prop[index][5]}\""
                        bat encoding: 'UTF-8',label: 'PackATS',  script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\AB\\${prop2.ATSDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.ATSDV}.zip C:\\K2JEN\\TEMP\\AB\\${prop2.ATSDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\AB\\${prop2.ATSDV}\\&&move /Y ${prop2.ATSDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\ATS\\"

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmATS-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_ATS_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmATS-F',  script: "if exist ABSwitch_ATS_${timestamp} rmdir /s /q ABSwitch_ATS_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                }
            }
        }       
        stage('FetchDESIGN'){

            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    CCloc = prop[index][2]
                    // print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("DesignBaseline")){
                        timetime = Calendar.getInstance().getTimeInMillis();
                        sleep 2
                        bat encoding: 'UTF-8',label: 'FetchDesign',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ABSwitch_Design_${timestamp} -s ${CCURL} -b ${prop2.DesignBaseline} \"${prop[index][7]}\""
                        sleep 10
                        string11 = "cd \"ABSwitch_Design_${timestamp}${prop[index][7]}\""
                        bat encoding: 'UTF-8',label: 'PackDesign',  script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\AB\\${prop2.DesignBaseline}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.DesignBaseline}.zip C:\\K2JEN\\TEMP\\AB\\${prop2.DesignBaseline}&&rmdir /s /q C:\\K2JEN\\TEMP\\AB\\${prop2.DesignBaseline}\\&&move /Y ${prop2.DesignBaseline}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\DESIGN\\"

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmDesign-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_Design_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmDesign-F',  script: "if exist ABSwitch_Design_${timestamp} rmdir /s /q ABSwitch_Design_${timestamp} "
                    }
                    else{
                        print('No Need')
                    }
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    if (prop2.containsKey("MSSBaseline")){
                        FetchMSS = true
                    }
                    else{
                         FetchMSS = false
                    }
                    
                }
            }
        }
        stage('FetchMSS'){
            when {
                expression {
                    return (FetchMSS==true)
                }
            }
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    CCloc = prop[index][2]
                    // print(CCloc)
                    CCURL = ""
                    if(CCloc == "北京"){
                        CCURL="http://172.19.100.116/ccrc"
                    }
                    if(CCloc == "上海"){
                        CCURL="http://192.100.99.215/ccrc"
                    }
                    if (prop2.containsKey("MSSBaseline")){

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchMSS',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ABSwitch_MSS_${timestamp} -s ${CCURL} -b ${prop2.MSSBaseline} \"${prop[index][10]}\""
                        sleep 10
                        string11 = "cd \"ABSwitch_MSS_${timestamp}${prop[index][10]}\""
                        bat encoding: 'UTF-8',label: 'PackMSS',  script: "${string11}"+"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\AB\\${prop2.MSSDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop2.MSSDV}.zip C:\\K2JEN\\TEMP\\AB\\${prop2.MSSDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\AB\\${prop2.MSSDV}\\&&move /Y ${prop2.MSSDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop[index][1]}\\MSS\\"

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmMSS-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_MSS_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmMSS-F',  script: "if exist ABSwitch_MSS_${timestamp} rmdir /s /q ABSwitch_MSS_${timestamp} "
                        bat encoding: 'UTF-8',label: 'echo mssver', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c \"echo ${prop2.MSSDV};${prop2.MSSSV}>C:\\AB\\mssver.txt\""
                        print("C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c \"echo ${prop2.MSSSV};${prop2.MSSDV}>C:\\AB\\mssver.txt\"")
                    
                    }
                    else{
                        print('No Need')
                    }
                }
            }
            
        }
        stage('Deploy'){

            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    bat encoding: 'UTF-8',label: 'stopallsim',  script: "C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\stopallsim.exe"
                    bat encoding: 'UTF-8',label: 'Deploy', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\FIVP_Tools-2.exe 2 1 ${prop[index][1]} ${prop2.CIDV} ${prop2.SDMSV} ${prop2.HMISV} ${prop2.ATSDV} ${prop2.ATSSV}"                        
                }
            }
        }
        // stage('TLEgenerate'){
            // steps {
                // script {
                    // prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    // prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    // int index = 0
                    // for (int i=0; i<prop.size(); i++){
                        // if (prop[i][0] == prop2.ProjectNumber){
                            // index = i
                            // break
                        // }
                    // }
                    // bat encoding: 'UTF-8',label: 'TLEgenerate', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c D:\\TLEResource\\TLEAnalysis.exe ${prop[index][1]} ${prop2.ATSDV} ${prop2.TLEDV}"              
                    // print("C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c D:\\TLEResource\\TLEAnalysis.exe ${prop[index][1]} ${prop2.ATSDV} ${prop2.TLEDV}")
                // }
            // }
        // }
        stage('ABTest'){

            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    print("C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c C:\\AB\\main_DI.exe ${prop[index][1]} ${prop2.CIDV} ${prop2.VLESV} ${prop2.SDMSV} ${prop2.ATSDV} ${prop2.ATSSV} ${prop2.HMISV} ${prop2.DesignBaseline} ${prop2.TLESV} ${prop2.K2NO[0]} ${prop2.K2NO[1]}")
         
                    bat encoding: 'UTF-8',label: 'ABTest', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\CBI-Q-EGG-1 -u administrator -p casco -i cmd /c C:\\AB\\main_DI.exe ${prop[index][1]} ${prop2.CIDV} ${prop2.VLESV} ${prop2.SDMSV} ${prop2.ATSDV} ${prop2.ATSSV} ${prop2.HMISV} ${prop2.DesignBaseline} ${prop2.TLESV} ${prop2.K2NO[0]} ${prop2.K2NO[1]}"
                }
            }
        }
        stage('FetchResult'){
            // when {
                // expression {
                    // return (DVCOM=='0')
                // }
            // }
            steps {
                script {                      
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    resultjson = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\${prop2.K2NO[0]}_${prop2.K2NO[1]}.json"
                    IS_PASS = resultjson.IS_PASS? resultjson.IS_PASS : false
                    println "IS_PASS:" + IS_PASS                    
                }
            }
        }
        stage('Fail'){
            when {
                expression {
                    return (IS_PASS==false)
                }
            }
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    println "${prop2.K2NO[0]} ${prop2.K2NO[1]}:Result Fail" 
                    bat encoding: 'UTF-8',label: 'copy_for_email',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.json (copy /Y E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.*)"
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----RESULT-----NOK>>${logname}"
                    emailstring=""
                    for (int i=0; i<prop2.Email.size(); i++){
                        emailstring=emailstring+prop2.Email[i]+","                       
                    }
                    print(emailstring)
                    if (ifEmail=="true"){
                        emailext (
                        body: """
                            <html>    
                                <head>    
                                    <meta charset="UTF-8">    
                                    <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                                </head>                          
                                <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                    <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                        <tr>    
                                            本邮件由系统自动发出，无需回复<br/>            
                                            以下为${prop2.K2NO[0]} ${prop2.K2NO[1]} 双机测试任务信息</br>                                          
                                        </tr>    
                                        <tr>    
                                            <td><br/>    
                                            <b><font color="#0B610B">任务信息</font></b>    
                                            <hr size="2" width="100%" align="center" /></td>    
                                        </tr>    
                                        <tr>    
                                            <td>    
                                                <ul>    
                                                    <li>项目名称 ： ${prop[index][1]}</li> 
                                                    <li>任务发起 ： ${PC}</li>
                                                    <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>                                                   
                                                    <li>触发原因 ： \${CAUSE}</li>    
                                                    <li>任务状态 ： \${BUILD_STATUS} 不通过</li>    
                                                    <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                    <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                    <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                    <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                    <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                       
                                                </ul>         
                                            </td>                                         
                                        </tr>    
                                    </table>    
                                </body>    
                            </html>  
                        """, 
                        subject: "[系统自动发送][双机测试完成:不通过]${PC}发起的${prop[index][1]}项目, ${prop2.K2NO[0]} ${prop2.K2NO[1]},请查看日志及结果", 
                        from: "FIVPServer@casco.com.cn",
                        to: "${emailstring}",
                        attachmentsPattern:"*.xlsx,*.log,*.zip"
                        )
                    }
                }
            }
        }
        stage('PASS'){
            when {
                expression {
                    return (IS_PASS==true)
                }
            }
            steps {
                script {
                    prop = readCSV file: "C:\\K2JEN\\main\\config\\config.csv"
                    prop2 = readJSON file: "E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json"
                    int index = 0
                    for (int i=0; i<prop.size(); i++){
                        if (prop[i][0] == prop2.ProjectNumber){
                            index = i
                            break
                        }
                    }
                    println "${prop2.K2NO[0]} ${prop2.K2NO[1]}:Result PASS" 
                    bat encoding: 'UTF-8',label: 'copy_for_email',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.json (copy /Y E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.*)"
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----RESULT-----OK>>${logname}"
                    emailstring=""
                    for (int i=0; i<prop2.Email.size(); i++){
                        emailstring=emailstring+prop2.Email[i]+","                       
                    }
                    print(emailstring)
                    if (ifEmail=="true"){
                        emailext (
                        body: """
                            <html>    
                                <head>    
                                    <meta charset="UTF-8">    
                                    <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                                </head>                          
                                <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                    <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                        <tr>    
                                            本邮件由系统自动发出，无需回复<br/>            
                                            以下为${prop2.K2NO[0]} ${prop2.K2NO[1]} 双机测试任务信息<br/>      
                                            由于部分项目CI BOOL数据入库未统一，程序暂不检查用例0022步骤6，需要测试人员人工查看附件version check压缩包中，MSS/SDM导出的ADSversion和CI BOOL包中是否一致<br/>                                                 
                                        </tr>    
                                        <tr>    
                                            <td><br/>    
                                            <b><font color="#0B610B">任务信息</font></b>    
                                            <hr size="2" width="100%" align="center" /></td>    
                                        </tr>    
                                        <tr>    
                                            <td>    
                                                <ul>    
                                                    <li>项目名称 ： ${prop[index][1]}</li> 
                                                    <li>任务发起 ： ${PC}</li>
                                                    <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>                                                   
                                                    <li>触发原因 ： \${CAUSE}</li>    
                                                    <li>任务状态 ： \${BUILD_STATUS} 通过</li>    
                                                    <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                    <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                    <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                    <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                    <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                       
                                                </ul>         
                                            </td>                                         
                                        </tr>    
                                    </table>    
                                </body>    
                            </html>  
                        """, 
                        subject: "[系统自动发送][双机测试完成:通过]${PC}发起的${prop[index][1]}项目, ${prop2.K2NO[0]} ${prop2.K2NO[1]},请查看日志及结果", 
                        from: "FIVPServer@casco.com.cn",
                        to: "${emailstring}",
                        attachmentsPattern:"*.xlsx,*.log,*.zip"
                        )
                    }
                }
            }
        }
    }
    post {
        success {
            script {
                bat encoding: 'UTF-8',label: 'Success_move_para_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json (move /Y E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json C:\\K2JEN\\TEMP\\ABOKBak\\)"
                bat encoding: 'UTF-8',label: 'Success_move_log_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.json (move /Y E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.* C:\\K2JEN\\TEMP\\ABProcessBak\\)"
                String endtime = java.time.LocalDateTime.now()
                bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----Process-----SUCCESS-----${endtime}>>${logname}"
                
            }
        }
        failure {
            script {
                bat encoding: 'UTF-8',label: 'Fail_move_para_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json (move /Y E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json C:\\K2JEN\\TEMP\\ABFailBak\\)"
                bat encoding: 'UTF-8',label: 'Fail_move_log_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.json (move /Y E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.* C:\\K2JEN\\TEMP\\ABProcessBak\\)"
                // bat encoding: 'UTF-8',label: 'Create_failure_flag',  script: "echo fail>E:\\FIVP_Tools\\FIVP_Tools\\ABSwitchAnalysis\\${Name}.fail"
                // bat encoding: 'UTF-8',label: 'Remove_para_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABSwitchAnalysis\\${Name}.txt (del /s /q E:\\FIVP_Tools\\FIVP_Tools\\ABSwitchAnalysis\\${Name}.txt)"
                loginfo = readFile 'C:\\K2JEN\\tools\\cclogin.ini'
                user = loginfo.tokenize()[0]
                pass = loginfo.tokenize()[1]

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'login',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch"
                sleep 5

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmCI-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_CI_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmCI-F',  script: "if exist ABSwitch_CI_${timestamp} rmdir /s /q ABSwitch_CI_${timestamp} "
                    
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATS-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_ATS_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmATS-F',  script: "if exist ABSwitch_ATS_${timestamp} rmdir /s /q ABSwitch_ATS_${timestamp} "
                    
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmDesign-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_Design_${timestamp} "
                bat encoding: 'UTF-8',label: 'rmDesign-F',  script: "if exist ABSwitch_Design_${timestamp} rmdir /s /q ABSwitch_Design_${timestamp} "
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmMSS-V',  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${CCURL} -v ABSwitch_MSS_${timestamp} "
                sleep 2
                bat encoding: 'UTF-8',label: 'rmMSS-F',  script: "if exist ABSwitch_MSS_${timestamp} rmdir /s /q ABSwitch_MSS_${timestamp} "
                        
                String endtime = java.time.LocalDateTime.now()
                bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----Process-----FAIL-----${endtime}>>${logname}"
                   
            }
        }
        aborted {
            script {
                String endtime = java.time.LocalDateTime.now()
                bat encoding: 'UTF-8',label: 'Fail_move_para_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json (move /Y E:\\FIVP_Tools\\FIVP_Tools\\ABSwitch\\${Time}_${PC}_${Proj}.json C:\\K2JEN\\TEMP\\ABFailBak\\)"
                bat encoding: 'UTF-8',label: 'Fail_move_log_file',  script: "if exist E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.json (move /Y E:\\FIVP_Tools\\FIVP_Tools\\ABResult\\*.* C:\\K2JEN\\TEMP\\ABProcessBak\\)"
                bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----Process-----ABORTED-----${endtime}>>${logname}"
            }            
        }
    }
}
