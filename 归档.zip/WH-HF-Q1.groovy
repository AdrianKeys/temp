//HF1bak
import java.util.Calendar;
pipeline {
    agent any
    environment {
        DATETIME_TAG = java.time.LocalDateTime.now()
        DATE_TAG = java.time.LocalDate.now()
        TIME_TAG = java.time.LocalTime.now().withNano(0)
		timestamp = Calendar.getInstance().getTimeInMillis()

    }
    stages {
        stage('Initialize') {
            steps {
                script {
                    bat encoding: 'UTF-8',label: 'Initialize1', returnStdout: true, script: 'if exist jsonforHF1.json (del /F /Q jsonforHF1.json)'
                    bat encoding: 'UTF-8',label: 'GetConfigFile', returnStdout: true, script: 'if exist C:\\K2JEN\\json\\jsonforHF1.json (move /Y C:\\K2JEN\\json\\jsonforHF1.json) else echo filedoesnotexist'
					prop = readJSON file: 'jsonforHF1.json' 
                    bat encoding: 'UTF-8',label: 'stopallsim', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\HF-Q-LWS-1 -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\stopallsim.exe"
                }                    
            }
        }
        stage('Fetch') {
            steps {
                script {
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)                    
                                        
                    prop = readJSON file: 'jsonforHF1.json'
                    bat encoding: 'UTF-8',label: 'makedirs', returnStdout: true, script: """if exist D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\CI\\ (
                    echo exist
                    ) else (
                    md D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\CI\\ 
                    )

                    if exist D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\ATS\\ (
                    echo exist
                    ) else (
                    md D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\ATS\\ 
                    )
                    
                    if exist D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\DESIGN\\ (
                    echo exist
                    ) else (
                    md D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\DESIGN\\ 
                    )
                    
                    if exist D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\SYDB\\ (
                    echo exist
                    ) else (
                    md D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\SYDB\\ 
                    )
                    
                    if exist D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\MSS\\ (
                    echo exist
                    ) else (
                    md D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\MSS\\ 
                    )

                    if exist D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\ATC\\ (
                    echo exist
                    ) else (
                    md D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\ATC\\ 
                    )"""
                    
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'login', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_CI_${timestamp}"   
                    sleep 5
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'FetchCI', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v WH_HF1_CC_06_CI_${timestamp} -s ${prop.CCServer} -b ${prop.CIBaseline} \"${prop.CIpath}\""
                    sleep 5
                    bat encoding: 'UTF-8',label: 'PackCI', returnStdout: true, script: "cd \"WH_HF1_CC_06_CI_${timestamp}${prop.CIpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\HF1\\${prop.CIDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.CIDV}.zip C:\\K2JEN\\TEMP\\HF1\\${prop.CIDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\HF1\\${prop.CIDV}\\&&move /Y ${prop.CIDV}.zip D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\CI\\"
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'FetchATS', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v WH_HF1_CC_06_ATS_${timestamp} -s ${prop.CCServer} -b ${prop.ATSBaseline} \"${prop.ATSpath}\""
                    sleep 5
                    bat encoding: 'UTF-8',label: 'PackATS', returnStdout: true, script: "cd \"WH_HF1_CC_06_ATS_${timestamp}${prop.ATSpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\HF1\\${prop.ATSDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.ATSDV}.zip C:\\K2JEN\\TEMP\\HF1\\${prop.ATSDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\HF1\\${prop.ATSDV}\\&&move /Y ${prop.ATSDV}.zip D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\ATS\\"
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'FetchATC', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v WH_HF1_CC_06_ATC_${timestamp} -s ${prop.CCServer} -b ${prop.ATCBaseline} \"${prop.ATCpath}\""
                    sleep 6
                    bat encoding: 'UTF-8',label: 'PackATC', returnStdout: true, script: "cd \"WH_HF1_CC_06_ATC_${timestamp}${prop.ATCpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\HF1\\${prop.ATCDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.ATCDV}.zip C:\\K2JEN\\TEMP\\HF1\\${prop.ATCDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\HF1\\${prop.ATCDV}\\&&move /Y ${prop.ATCDV}.zip D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\ATC\\"
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'FetchDesign', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v WH_HF1_CC_06_DESIGN_${timestamp} -s ${prop.CCServer} -b ${prop.DesignBaseline} \"${prop.Designpath}\""
                    sleep 6
                    if (prop.containsKey("SIG-RSpath")){                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchSIG-RS', returnStdout: true, script: "xcopy /c /r /y \"${prop.SIG-RSpath}\" C:\\K2JEN\\TEMP\\HF1\\${prop.DesignBaseline}\\"
                    }
                    bat encoding: 'UTF-8',label: 'PackDesign', returnStdout: true, script: "cd \"WH_HF1_CC_06_DESIGN_${timestamp}${prop.Designpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\HF1\\${prop.DesignBaseline}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.DesignBaseline}.zip C:\\K2JEN\\TEMP\\HF1\\${prop.DesignBaseline}&&rmdir /s /q C:\\K2JEN\\TEMP\\HF1\\${prop.DesignBaseline}\\&&move /Y ${prop.DesignBaseline}.zip D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\DESIGN\\"
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'FetchSYDB', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v WH_HF1_CC_06_SYDB_${timestamp}  -s ${prop.CCServer} -b ${prop.SysDataBaseline} \"${prop.SYDBpath}\""
                    sleep 6
                    bat encoding: 'UTF-8',label: 'PackSYDB ', returnStdout: true, script: "cd \"WH_HF1_CC_06_SYDB_${timestamp}${prop.SYDBpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\HF1\\${prop.SYDB}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.SYDB}.zip C:\\K2JEN\\TEMP\\HF1\\${prop.SYDB}&&rmdir /s /q C:\\K2JEN\\TEMP\\HF1\\${prop.SYDB}\\&&move /Y ${prop.SYDB}.zip D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\SYDB\\"
                    
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'rmCI-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_CI_${timestamp} "
                    sleep 2
                    bat encoding: 'UTF-8',label: 'rmCI-F', returnStdout: true, script: "if exist WH_HF1_CC_06_CI_${timestamp} rmdir /s /q WH_HF1_CC_06_CI_${timestamp} "
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'rmATS-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_ATS_${timestamp} "   
                    sleep 2
                    bat encoding: 'UTF-8',label: 'rmATS-F', returnStdout: true, script: "if exist WH_HF1_CC_06_ATS_${timestamp} rmdir /s /q WH_HF1_CC_06_ATS_${timestamp} "                    
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'rmATC-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_ATC_${timestamp} "   
                    sleep 2
                    bat encoding: 'UTF-8',label: 'rmATC-F', returnStdout: true, script: "if exist WH_HF1_CC_06_ATC_${timestamp} rmdir /s /q WH_HF1_CC_06_ATC_${timestamp} "      
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'rmDesign-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_DESIGN_${timestamp} "   
                    sleep 2
                    bat encoding: 'UTF-8',label: 'rmDesign-F', returnStdout: true, script: "if exist WH_HF1_CC_06_DESIGN_${timestamp} rmdir /s /q WH_HF1_CC_06_DESIGN_${timestamp} "         

                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: 'UTF-8',label: 'rmSYDB-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_SYDB_${timestamp} "   
                    sleep 2
                    bat encoding: 'UTF-8',label: 'rmSYDB-F', returnStdout: true, script: "if exist WH_HF1_CC_06_SYDB_${timestamp} rmdir /s /q WH_HF1_CC_06_SYDB_${timestamp}"          
                    
    				// emailext (
                        // subject: "[系统自动发送][流程启动]${prop.IPSource}发起的${prop.ProjectNumber}项目, 已在${env.JOB_NAME}启动流程",
                        // body: """
                            // <p>项目简称: ${prop.ProjectNumber}</p>
                            // <p>发布单号: ${prop.K2NO}</p>
                            // <p>测试类型: ${prop.TestSubsystem}</p>
                            // <p>任务发起: ${prop.IPSource}</p>
                            // <p>启动时间: ${DATE_TAG}, ${TIME_TAG}</p>
                            // <p>测试环境: ${env.JOB_NAME}</p>
                            // <p>测试流程启动                           </p>
                            // <p>请登录"<a href="\${PROJECT_URL}">\${PROJECT_URL}</a>"查看流程进度, 登陆用户名: FIVP, 密码: FIVP。</p>
                            // """,
                        // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}",
                        // from: "FIVPServer@casco.com.cn"
                    // )
                    
                    FetchMSS=false
                    if (prop.containsKey("MSSBaseline")){
                        if (prop.MSSBaseline!="0"){
                            FetchMSS = true
                            print('msstrue')
                        }
                    }
                    else{
                         FetchMSS = false
                         print('mssfalse')
                    }
                    
                }
            }
        } 
        stage('FetchMSS'){
            when {
                expression {
                    return (FetchMSS==true)
                }
            }
            steps {
                script {
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)                  
                                        
                    prop = readJSON file: 'jsonforHF1.json'
                    if (prop.containsKey("MSSBaseline")){

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'FetchMSS', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v WH_HF1_CC_06_MSS_${timestamp} -s ${prop.CCServer} -b ${prop.MSSBaseline} \"${prop.MSSpath}\""
                        sleep 10
                        bat encoding: 'UTF-8',label: 'PackMSS', returnStdout: true, script: "cd \"WH_HF1_CC_06_MSS_${timestamp}${prop.MSSpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\HF1\\${prop.MSSDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.MSSDV}.zip C:\\K2JEN\\TEMP\\HF1\\${prop.MSSDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\HF1\\${prop.MSSDV}\\&&move /Y ${prop.MSSDV}.zip D:\\FIVP_Database\\FIVP_Tools\\Data\\${prop.ProjectNumber}\\MSS\\"
                    
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: 'UTF-8',label: 'rmMSS-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_MSS_${timestamp} "
                        sleep 2
                        bat encoding: 'UTF-8',label: 'rmMSS-F', returnStdout: true, script: "if exist WH_HF1_CC_06_MSS_${timestamp} rmdir /s /q WH_HF1_CC_06_MSS_${timestamp} "

                    }
                    else{
                        print('No Need')
                    }
                }
            }
            
        }
        
        stage('Deploy') {
            steps {
                script {
                    prop = readJSON file: 'jsonforHF1.json'
                    bat encoding: 'UTF-8',label: '', script: 'if exist C:\\K2JEN\\deploy\\batforHF1.bat (move /Y C:\\K2JEN\\deploy\\batforHF1.bat) else echo filedoesnotexist'
                    sleep 5
                    bat encoding: 'UTF-8',label :'bat for cdt generation',script:"if exist batforHF1.bat (start batforHF1.bat)"
                    bat encoding: 'UTF-8',label: 'deploy', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\HF-Q-LWS-1 -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\FIVP_Tools029-1.exe 2 1 ${prop.ProjectNumber} ${prop.CIDV} ${prop.SDMSV} ${prop.HMISV} ${prop.ATSDV} ${prop.ATSSV}"
                                  
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
                    // emailext (
                        // subject: "[系统自动发送][部署完成]${prop.IPSource}发起的${prop.ProjectNumber}项目, 已在${env.JOB_NAME}完成部署，即将进行测试",
                        // body: """
                            // <p>项目简称: ${prop.ProjectNumber}</p>
                            // <p>发布单号: ${prop.K2NO}</p>
                            // <p>测试类型: ${prop.TestSubsystem}</p>
                            // <p>任务发起: ${prop.IPSource}</p>
                            // <p>部署时间: ${DATE_TAG}, ${TIME_TAG}</p>
                            // <p>测试环境: ${env.JOB_NAME}</p>
                            // <p>部署完成                           </p>
                            // <p>请登录"<a href="\${PROJECT_URL}">\${PROJECT_URL}</a>"查看流程进度, 登陆用户名: FIVP, 密码: FIVP。</p>
                            // """,
                        // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}",
                        // from: "FIVPServer@casco.com.cn"
                    // )
                }
            }
        }
        stage('Start') {
            steps {
                script {
                    prop = readJSON file: 'jsonforHF1.json'
                    bat encoding: 'UTF-8',label: 'start', script: "C:\\K2JEN\\tools\\PsExec.exe \\\\HF-Q-LWS-1 -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\startallsim.exe ${prop.ProjectNumber} ${prop.CIDV} ${prop.ATSDV} ${prop.ATSSV} ${prop.HMISV} ${prop.SDMSV}"
                                  
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
                    // emailext (
                        // subject: "[系统自动发送][部署完成]${prop.IPSource}发起的${prop.ProjectNumber}项目, 已在${env.JOB_NAME}完成部署，即将进行测试",
                        // body: """
                            // <p>项目简称: ${prop.ProjectNumber}</p>
                            // <p>发布单号: ${prop.K2NO}</p>
                            // <p>测试类型: ${prop.TestSubsystem}</p>
                            // <p>任务发起: ${prop.IPSource}</p>
                            // <p>部署时间: ${DATE_TAG}, ${TIME_TAG}</p>
                            // <p>测试环境: ${env.JOB_NAME}</p>
                            // <p>部署完成                           </p>
                            // <p>请登录"<a href="\${PROJECT_URL}">\${PROJECT_URL}</a>"查看流程进度, 登陆用户名: FIVP, 密码: FIVP。</p>
                            // """,
                        // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}",
                        // from: "FIVPServer@casco.com.cn"
                    // )
                }
            }
        }
    }
    post {
        success {
            script{
                prop = readJSON file: 'jsonforHF1.json'    
                DATE_TAG = java.time.LocalDate.now()
                TIME_TAG = java.time.LocalTime.now().withNano(0)
                // emailext (
                    // attachmentsPattern: 'results\\*.xls',
                    // body: """
                        // <html>    
                            // <head>    
                                // <meta charset="UTF-8">    
                                // <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                            // </head>                          
                            // <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                // <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                    // <tr>    
                                        // 本邮件由系统自动发出，无需回复<br/>            
                                        // 以下为${prop.ProjectNumber}项目，对应K2单${prop.K2NO}的构建信息</br> 
                                        // <td><b><font color="#0B610B">构建结果 - \${BUILD_STATUS}</font></b></td>   
                                    // </tr>    
                                    // <tr>    
                                        // <td><br/>    
                                        // <b><font color="#0B610B">构建信息</font></b>    
                                        // <hr size="2" width="100%" align="center" /></td>    
                                    // </tr>    
                                    // <tr>    
                                        // <td>    
                                            // <ul>    
                                                // <li>项目名称 ： ${prop.ProjectNumber}</li>     
                                                // <li>发布单号 ： ${prop.K2NO}</li>
                                                // <li>测试类型 ： ${prop.TestSubsystem}</li>
                                                // <li>任务发起 ： ${prop.IPSource}</li>
                                                // <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>
                                                // <li>测试环境 ： \${PROJECT_NAME}</li>    
                                                // <li>触发原因 ： \${CAUSE}</li>    
                                                // <li>任务状态 ： \${BUILD_STATUS}</li>    
                                                // <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                // <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                // <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                // <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                // <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>   
                                            // </ul>         
                                        // </td> 
                                    // </tr>    
                                // </table>    
                            // </body>    
                        // </html>  
                    // """, 
                    // subject: "[系统自动发送][测试完成]${prop.IPSource}发起的${prop.ProjectNumber} ${prop.TestSubsystem}项目, 已完成${prop.K2NO}部署", 
                    // from: "FIVPServer@casco.com.cn",
                    // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}"
                // )
            }            
        }
        aborted {
            script{
                prop = readJSON file: 'jsonforHF1.json'   
                DATE_TAG = java.time.LocalDate.now()
                TIME_TAG = java.time.LocalTime.now().withNano(0)    
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'login', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_CI_${timestamp}"   
                sleep 5

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmCI-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_CI_${timestamp} "
                sleep 2
                bat encoding: 'UTF-8',label: 'rmCI-F', returnStdout: true, script: "if exist WH_HF1_CC_06_CI_${timestamp} rmdir /s /q WH_HF1_CC_06_CI_${timestamp} "
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATS-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_ATS_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmATS-F', returnStdout: true, script: "if exist WH_HF1_CC_06_ATS_${timestamp} rmdir /s /q WH_HF1_CC_06_ATS_${timestamp} "                    
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATC-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_ATC_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmATC-F', returnStdout: true, script: "if exist WH_HF1_CC_06_ATC_${timestamp} rmdir /s /q WH_HF1_CC_06_ATC_${timestamp} "      
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmDesign-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_DESIGN_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmDesign-F', returnStdout: true, script: "if exist WH_HF1_CC_06_DESIGN_${timestamp} rmdir /s /q WH_HF1_CC_06_DESIGN_${timestamp} "         

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmSYDB-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_SYDB_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmSYDB-F', returnStdout: true, script: "if exist WH_HF1_CC_06_SYDB_${timestamp} rmdir /s /q WH_HF1_CC_06_SYDB_${timestamp}"  
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmMSS-V', script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_MSS_${timestamp} "
                sleep 2
                bat encoding: 'UTF-8',label: 'rmMSS-F', script: "if exist WH_HF1_CC_06_MSS_${timestamp} rmdir /s /q WH_HF1_CC_06_MSS_${timestamp} "

                // emailext (
                    // body: """
                        // <html>    
                            // <head>    
                                // <meta charset="UTF-8">    
                                // <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                            // </head>                          
                            // <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                // <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                    // <tr>    
                                        // 本邮件由系统自动发出，无需回复<br/>            
                                        // 以下为${prop.ProjectNumber}项目，对应K2单${prop.K2NO}的任务信息</br> 
                                        // <td><font color="#0B610B">任务结果 - \${BUILD_STATUS}</font></td>   
                                    // </tr>    
                                    // <tr>    
                                        // <td><br/>    
                                        // <b><font color="#0B610B">任务信息</font></b>    
                                        // <hr size="2" width="100%" align="center" /></td>    
                                    // </tr>    
                                    // <tr>    
                                        // <td>    
                                            // <ul>    
                                                // <li>项目名称 ： ${prop.ProjectNumber}</li>     
                                                // <li>发布单号 ： ${prop.K2NO}</li>
                                                // <li>测试类型 ： ${prop.TestSubsystem}</li>
                                                // <li>任务发起 ： ${prop.IPSource}</li>
                                                // <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>
                                                // <li>测试环境 ： \${PROJECT_NAME}</li>    
                                                // <li>触发原因 ： \${CAUSE}</li>    
                                                // <li>任务状态 ： \${BUILD_STATUS}</li>    
                                                // <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                // <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                // <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                // <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                // <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                         
                                            // </ul>         
                                        // </td>                                         
                                    // </tr>    
                                // </table>    
                            // </body>    
                        // </html>  
                    // """, 
                    // subject: "[系统自动发送][测试中断]${prop.IPSource}发起的${prop.ProjectNumber} ${prop.TestSubsystem}项目, 发布单号：${prop.K2NO}, 因超时中断部署", 
                    // from: "FIVPServer@casco.com.cn",
                    // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}"
                // )
            }
        }
        failure {
            script{
                prop = readJSON file: 'jsonforHF1.json'   
                DATE_TAG = java.time.LocalDate.now()
                TIME_TAG = java.time.LocalTime.now().withNano(0)
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'login', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_CI_${timestamp}"   
                sleep 5
                    
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmCI-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_CI_${timestamp} "
                sleep 2
                bat encoding: 'UTF-8',label: 'rmCI-F', returnStdout: true, script: "if exist WH_HF1_CC_06_CI_${timestamp} rmdir /s /q WH_HF1_CC_06_CI_${timestamp} "
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATS-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_ATS_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmATS-F', returnStdout: true, script: "if exist WH_HF1_CC_06_ATS_${timestamp} rmdir /s /q WH_HF1_CC_06_ATS_${timestamp} "                    
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmATC-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_ATC_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmATC-F', returnStdout: true, script: "if exist WH_HF1_CC_06_ATC_${timestamp} rmdir /s /q WH_HF1_CC_06_ATC_${timestamp} "      
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmDesign-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_DESIGN_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmDesign-F', returnStdout: true, script: "if exist WH_HF1_CC_06_DESIGN_${timestamp} rmdir /s /q WH_HF1_CC_06_DESIGN_${timestamp} "         

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmSYDB-V', returnStdout: true, script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_SYDB_${timestamp} "   
                sleep 2
                bat encoding: 'UTF-8',label: 'rmSYDB-F', returnStdout: true, script: "if exist WH_HF1_CC_06_SYDB_${timestamp} rmdir /s /q WH_HF1_CC_06_SYDB_${timestamp}"  
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: 'UTF-8',label: 'rmMSS-V', script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -s ${prop.CCServer} -v WH_HF1_CC_06_MSS_${timestamp} "
                sleep 2
                bat encoding: 'UTF-8',label: 'rmMSS-F', script: "if exist WH_HF1_CC_06_MSS_${timestamp} rmdir /s /q WH_HF1_CC_06_MSS_${timestamp} "
                // emailext (
                    // body: """
                        // <html>    
                            // <head>    
                                // <meta charset="UTF-8">    
                                // <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                            // </head>                          
                            // <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                // <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                    // <tr>    
                                        // 本邮件由系统自动发出，无需回复<br/>            
                                        // 以下为${prop.ProjectNumber}项目，对应K2单${prop.K2NO}的任务信息</br> 
                                        // <td><font color="#0B610B">任务结果 - \${BUILD_STATUS}</font></td>   
                                    // </tr>    
                                    // <tr>    
                                        // <td><br/>    
                                        // <b><font color="#0B610B">任务信息</font></b>    
                                        // <hr size="2" width="100%" align="center" /></td>    
                                    // </tr>    
                                    // <tr>    
                                        // <td>    
                                            // <ul>    
                                                // <li>项目名称 ： ${prop.ProjectNumber}</li>     
                                                // <li>发布单号 ： ${prop.K2NO}</li>
                                                // <li>测试类型 ： ${prop.TestSubsystem}</li>
                                                // <li>任务发起 ： ${prop.IPSource}</li>
                                                // <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>
                                                // <li>测试环境 ： \${PROJECT_NAME}</li>    
                                                // <li>触发原因 ： \${CAUSE}</li>    
                                                // <li>任务状态 ： \${BUILD_STATUS}</li>    
                                                // <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                // <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                // <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                // <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                // <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                       
                                            // </ul>         
                                        // </td>                                         
                                    // </tr>    
                                // </table>    
                            // </body>    
                        // </html>  
                    // """, 
                    // subject: "[系统自动发送][测试失败]${prop.IPSource}发起的${prop.ProjectNumber} ${prop.TestSubsystem}项目, 发布单号：${prop.K2NO}, 失败，请查看日志", 
                    // from: "FIVPServer@casco.com.cn",
                    // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}"
                // )
            }
        }
    }
}
