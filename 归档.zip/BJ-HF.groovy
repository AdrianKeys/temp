import java.util.Calendar;
pipeline {
    agent any
    environment {
        DATETIME_TAG = java.time.LocalDateTime.now()
        DATE_TAG = java.time.LocalDate.now()
        TIME_TAG = java.time.LocalTime.now().withNano(0)
		timestamp = Calendar.getInstance().getTimeInMillis()
        index_str="HF1"
        target="HF-X-LWS-1"
        loc="BJ"
        
        Calendar cal = Calendar.getInstance();
        Month1 = cal.get(Calendar.MONTH);
        Year = cal.get(Calendar.YEAR);
        intMonth = Integer.parseInt("${Month1}")
        Month = String.valueOf(intMonth+1)
        logname = 'C:\\FIVP_Tools\\'+"${Year}"+'-'+"${Month}"+'-Deploy.log'
    }
    stages {
        stage("Initialize") {
            steps {
                script {   
                    String stime = java.time.LocalDateTime.now()
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----start-----${stime}>>${logname}"
                    bat encoding: "UTF-8",label: "cleanworkspace",  script: "del /S /Q  \"${WORKSPACE}\\*.*\""
                    bat encoding: "UTF-8",label: "GetConfigFile",  script: "if exist C:\\K2JEN\\json\\Jsonfor${index_str}.json (move /Y C:\\K2JEN\\json\\Jsonfor${index_str}.json) else echo filedoesnotexist"
					prop = readJSON file: "Jsonfor${index_str}.json" 
                    //bat encoding: "UTF-8",label: "stopallsim", script: "C:\\K2JEN\\tools\\PsExec.exe \\\\${target} -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\stopallsim.exe"
                }                    
            }
        }
        stage("Fetch") {
            steps {
                script {
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
                                        
                    prop = readJSON file: "Jsonfor${index_str}.json"
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----PROJ-----${prop.ProjectNumber}>>${logname}"
                    bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----K2NO-----${prop.K2NO}>>${logname}"
                    bat encoding: "UTF-8",label: "makedirs",  script: """if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\CI\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\CI\\ 
                    )

                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\ATS\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\ATS\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\DESIGN\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\DESIGN\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\SYDB\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\SYDB\\ 
                    )
                    
                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\MSS\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\MSS\\ 
                    )

                    if exist E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\ATC\\ (
                    echo exist
                    ) else (
                    md E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\ATC\\ 
                    )"""
                    
                    loginfo = readFile 'C:\\K2JEN\\tools\\cclogin.ini'
                    user = loginfo.tokenize()[0]
                    pass = loginfo.tokenize()[1]
                    
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: "UTF-8",label: "login",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_CI_${timestamp}"   
                    sleep 5
                    if (prop.CIBaseline!="0"){
                        timetime = Calendar.getInstance().getTimeInMillis();
                        print("C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_CI_${timestamp} -s ${prop.CCServer} -b ${prop.CIBaseline} \"${prop.CIpath}\"")
                        bat encoding: "UTF-8",label: "FetchCI",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_CI_${timestamp} -s ${prop.CCServer} -b ${prop.CIBaseline} \"${prop.CIpath}\""
                        sleep 5
                        bat encoding: "UTF-8",label: "PackCI",  script: "cd \"${loc}_${index_str}_CI_${timestamp}${prop.CIpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\${index_str}\\${prop.CIDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.CIDV}.zip C:\\K2JEN\\TEMP\\${index_str}\\${prop.CIDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\${index_str}\\${prop.CIDV}\\&&move /Y ${prop.CIDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\CI\\"
                    
                        sleep 2
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "rmCI-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_CI_${timestamp} "
                        sleep 2
                        bat encoding: "UTF-8",label: "rmCI-F",  script: "if exist ${loc}_${index_str}_CI_${timestamp} rmdir /s /q ${loc}_${index_str}_CI_${timestamp} "
                    
                    } else {
                        print("CI pass")
                    }
                    
                    
                    if (prop.ATSBaseline!="0"){
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "FetchATS",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_ATS_${timestamp} -s ${prop.CCServer} -b ${prop.ATSBaseline} \"${prop.ATSpath}\""
                        sleep 5
                        bat encoding: "UTF-8",label: "PackATS",  script: "cd \"${loc}_${index_str}_ATS_${timestamp}${prop.ATSpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\${index_str}\\${prop.ATSDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.ATSDV}.zip C:\\K2JEN\\TEMP\\${index_str}\\${prop.ATSDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\${index_str}\\${prop.ATSDV}\\&&move /Y ${prop.ATSDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\ATS\\"
                    
                        sleep 2
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "rmATS-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_ATS_${timestamp} "   
                        sleep 2
                        bat encoding: "UTF-8",label: "rmATS-F",  script: "if exist ${loc}_${index_str}_ATS_${timestamp} rmdir /s /q ${loc}_${index_str}_ATS_${timestamp} "                    
                    
                    } else {
                        print("ATS pass")
                    }
                    
                    if (prop.ATCBaseline!="0"){
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "FetchATC",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_ATC_${timestamp} -s ${prop.CCServer} -b ${prop.ATCBaseline} \"${prop.ATCpath}\""
                        sleep 6
                        bat encoding: "UTF-8",label: "PackATC",  script: "cd \"${loc}_${index_str}_ATC_${timestamp}${prop.ATCpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\${index_str}\\${prop.ATCDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.ATCDV}.zip C:\\K2JEN\\TEMP\\${index_str}\\${prop.ATCDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\${index_str}\\${prop.ATCDV}\\&&move /Y ${prop.ATCDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\ATC\\"
                        
                        sleep 2
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "rmATC-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_ATC_${timestamp} "   
                        sleep 2
                        bat encoding: "UTF-8",label: "rmATC-F",  script: "if exist ${loc}_${index_str}_ATC_${timestamp} rmdir /s /q ${loc}_${index_str}_ATC_${timestamp} "      
                    } else {
                        print("ATC pass")
                    }


                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: "UTF-8",label: "FetchDesign",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_DESIGN_${timestamp} -s ${prop.CCServer} -b ${prop.DesignBaseline} \"${prop.Designpath}\""
                    sleep 6
                    if (prop.containsKey("SIG-RSpath")){                        
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "FetchSIG-RS",  script: "xcopy /c /r /y \"${prop.SIG-RSpath}\" C:\\K2JEN\\TEMP\\${index_str}\\${prop.DesignBaseline}\\"
                    }
                    bat encoding: "UTF-8",label: "PackDesign",  script: "cd \"${loc}_${index_str}_DESIGN_${timestamp}${prop.Designpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\${index_str}\\${prop.DesignBaseline}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.DesignBaseline}.zip C:\\K2JEN\\TEMP\\${index_str}\\${prop.DesignBaseline}&&rmdir /s /q C:\\K2JEN\\TEMP\\${index_str}\\${prop.DesignBaseline}\\&&move /Y ${prop.DesignBaseline}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\DESIGN\\"
                
                    sleep 2
                    timetime = Calendar.getInstance().getTimeInMillis();
                    bat encoding: "UTF-8",label: "rmDesign-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_DESIGN_${timestamp} "   
                    sleep 2
                    bat encoding: "UTF-8",label: "rmDesign-F",  script: "if exist ${loc}_${index_str}_DESIGN_${timestamp} rmdir /s /q ${loc}_${index_str}_DESIGN_${timestamp} "         

                    
                    if (prop.SysDataBaseline!="0"){
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "FetchSYDB",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_SYDB_${timestamp}  -s ${prop.CCServer} -b ${prop.SysDataBaseline} \"${prop.SYDBpath}\""
                        sleep 6
                        bat encoding: "UTF-8",label: "PackSYDB ",  script: "cd \"${loc}_${index_str}_SYDB_${timestamp}${prop.SYDBpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\${index_str}\\${prop.SYDB}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.SYDB}.zip C:\\K2JEN\\TEMP\\${index_str}\\${prop.SYDB}&&rmdir /s /q C:\\K2JEN\\TEMP\\${index_str}\\${prop.SYDB}\\&&move /Y ${prop.SYDB}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\SYDB\\"
                    
                        sleep 2
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "rmSYDB-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_SYDB_${timestamp} "   
                        sleep 2
                        bat encoding: "UTF-8",label: "rmSYDB-F",  script: "if exist ${loc}_${index_str}_SYDB_${timestamp} rmdir /s /q ${loc}_${index_str}_SYDB_${timestamp}"          
                    } else {
                        print("SYDB pass")
                    }
                   
                    
    				// emailext (
                        // subject: "[系统自动发送][流程启动]${prop.IPSource}发起的${prop.ProjectNumber}项目, 已在${env.JOB_NAME}启动流程",
                        // body: """
                            // <p>项目简称: ${prop.ProjectNumber}</p>
                            // <p>发布单号: ${prop.K2NO}</p>
                            // <p>测试类型: ${prop.TestSubsystem}</p>
                            // <p>任务发起: ${prop.IPSource}</p>
                            // <p>启动时间: ${DATE_TAG}, ${TIME_TAG}</p>
                            // <p>测试环境: ${env.JOB_NAME}</p>
                            // <p>测试流程启动                           </p>
                            // <p>请登录"<a href="\${PROJECT_URL}">\${PROJECT_URL}</a>"查看流程进度, 登陆用户名: FIVP, 密码: FIVP。</p>
                            // """,
                        // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}",
                        // from: "FIVPServer@casco.com.cn"
                    // )
                    FetchMSS = false
                    if (prop.containsKey("MSSBaseline")){
                        if (prop.MSSBaseline!="0"){
                            FetchMSS = true
                            print("msstrue")
                        }
                    }
                    else{
                         FetchMSS = false
                         print("mssfalse")
                    }
                }
            }
        } 
        stage("FetchMSS"){
            when {
                expression {
                    return (FetchMSS==true)
                }
            }
            steps {
                script {
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)                  
                                        
                    prop = readJSON file: "Jsonfor${index_str}.json"
                    if (prop.containsKey("MSSBaseline")){

                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "FetchMSS",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe -t ${timetime} -v ${loc}_${index_str}_MSS_${timestamp} -s ${prop.CCServer} -b ${prop.MSSBaseline} \"${prop.MSSpath}\""
                        sleep 10
                        bat encoding: "UTF-8",label: "PackMSS",  script: "cd \"${loc}_${index_str}_MSS_${timestamp}${prop.MSSpath}\"&&xcopy /e /c /r /y *.* C:\\K2JEN\\TEMP\\${index_str}\\${prop.MSSDV}\\&&C:\\K2JEN\\tools\\7z.exe a -tzip  -r ${prop.MSSDV}.zip C:\\K2JEN\\TEMP\\${index_str}\\${prop.MSSDV}&&rmdir /s /q C:\\K2JEN\\TEMP\\${index_str}\\${prop.MSSDV}\\&&move /Y ${prop.MSSDV}.zip E:\\FIVP_Tools\\FIVP_Tools\\DATA\\${prop.ProjectNumber}\\MSS\\"
                    
                        timetime = Calendar.getInstance().getTimeInMillis();
                        bat encoding: "UTF-8",label: "rmMSS-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_MSS_${timestamp} "
                        sleep 2
                        bat encoding: "UTF-8",label: "rmMSS-F",  script: "if exist ${loc}_${index_str}_MSS_${timestamp} rmdir /s /q ${loc}_${index_str}_MSS_${timestamp} "

                    }
                    else{
                        print("No Need")
                    }
                }
            }
            
        }
        
        stage("Deploy") {
            steps {
                script {
                    prop = readJSON file: "Jsonfor${index_str}.json"
                    bat encoding: "UTF-8",label: "", script: "if exist C:\\K2JEN\\deploy\\batfor${index_str}.bat (move /Y C:\\K2JEN\\deploy\\batfor${index_str}.bat) else echo filedoesnotexist"
                    sleep 5
                    bat encoding: "UTF-8",label :"bat for cdt generation",script:"if exist batfor${index_str}.bat (start batfor${index_str}.bat)"
                    bat encoding: "UTF-8",label: "deploy", script: "C:\\K2JEN\\tools\\PsExec.exe \\\\${target} -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\FIVP_Tools-2.exe 2 1 ${prop.ProjectNumber} ${prop.CIDV} ${prop.SDMSV} ${prop.HMISV} ${prop.ATSDV} ${prop.ATSSV}"
                                  
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
                    // emailext (
                        // subject: "[系统自动发送][部署完成]${prop.IPSource}发起的${prop.ProjectNumber}项目, 已在${env.JOB_NAME}完成部署，即将进行测试",
                        // body: """
                            // <p>项目简称: ${prop.ProjectNumber}</p>
                            // <p>发布单号: ${prop.K2NO}</p>
                            // <p>测试类型: ${prop.TestSubsystem}</p>
                            // <p>任务发起: ${prop.IPSource}</p>
                            // <p>部署时间: ${DATE_TAG}, ${TIME_TAG}</p>
                            // <p>测试环境: ${env.JOB_NAME}</p>
                            // <p>部署完成                           </p>
                            // <p>请登录"<a href="\${PROJECT_URL}">\${PROJECT_URL}</a>"查看流程进度, 登陆用户名: FIVP, 密码: FIVP。</p>
                            // """,
                        // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}",
                        // from: "FIVPServer@casco.com.cn"
                    // )
                }
            }
        }
        stage("Start") {
            steps {
                script {
                    prop = readJSON file: "Jsonfor${index_str}.json"
                    bat encoding: "UTF-8",label: "start", script: "C:\\K2JEN\\tools\\PsExec.exe \\\\${target} -u administrator -p casco -i cmd /c C:\\FIVP_Tools\\deploy\\startallsim.exe ${prop.ProjectNumber} ${prop.CIDV} ${prop.ATSDV} ${prop.ATSSV} ${prop.HMISV} ${prop.SDMSV}"
                                  
                    DATE_TAG = java.time.LocalDate.now()
                    TIME_TAG = java.time.LocalTime.now().withNano(0)
                    // emailext (
                        // subject: "[系统自动发送][部署完成]${prop.IPSource}发起的${prop.ProjectNumber}项目, 已在${env.JOB_NAME}完成部署，即将进行测试",
                        // body: """
                            // <p>项目简称: ${prop.ProjectNumber}</p>
                            // <p>发布单号: ${prop.K2NO}</p>
                            // <p>测试类型: ${prop.TestSubsystem}</p>
                            // <p>任务发起: ${prop.IPSource}</p>
                            // <p>部署时间: ${DATE_TAG}, ${TIME_TAG}</p>
                            // <p>测试环境: ${env.JOB_NAME}</p>
                            // <p>部署完成                           </p>
                            // <p>请登录"<a href="\${PROJECT_URL}">\${PROJECT_URL}</a>"查看流程进度, 登陆用户名: FIVP, 密码: FIVP。</p>
                            // """,
                        // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}",
                        // from: "FIVPServer@casco.com.cn"
                    // )
                }
            }
        }
 
    }
    post {
        success {
            script{
                prop = readJSON file: "Jsonfor${index_str}.json"    
                DATE_TAG = java.time.LocalDate.now()
                TIME_TAG = java.time.LocalTime.now().withNano(0)
                String endtime = java.time.LocalDateTime.now()
                bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----Process-----SUCCESS-----${endtime}>>${logname}"
                // emailext (
                    // attachmentsPattern: "results\\*.xls",
                    // body: """
                        // <html>    
                            // <head>    
                                // <meta charset="UTF-8">    
                                // <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                            // </head>                          
                            // <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                // <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                    // <tr>    
                                        // 本邮件由系统自动发出，无需回复<br/>            
                                        // 以下为${prop.ProjectNumber}项目，对应K2单${prop.K2NO}的构建信息</br> 
                                        // <td><b><font color="#0B610B">构建结果 - \${BUILD_STATUS}</font></b></td>   
                                    // </tr>    
                                    // <tr>    
                                        // <td><br/>    
                                        // <b><font color="#0B610B">构建信息</font></b>    
                                        // <hr size="2" width="100%" align="center" /></td>    
                                    // </tr>    
                                    // <tr>    
                                        // <td>    
                                            // <ul>    
                                                // <li>项目名称 ： ${prop.ProjectNumber}</li>     
                                                // <li>发布单号 ： ${prop.K2NO}</li>
                                                // <li>测试类型 ： ${prop.TestSubsystem}</li>
                                                // <li>任务发起 ： ${prop.IPSource}</li>
                                                // <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>
                                                // <li>测试环境 ： \${PROJECT_NAME}</li>    
                                                // <li>触发原因 ： \${CAUSE}</li>    
                                                // <li>任务状态 ： \${BUILD_STATUS}</li>    
                                                // <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                // <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                // <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                // <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                // <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>   
                                            // </ul>         
                                        // </td> 
                                    // </tr>    
                                // </table>    
                            // </body>    
                        // </html>  
                    // """, 
                    // subject: "[系统自动发送][测试完成]${prop.IPSource}发起的${prop.ProjectNumber} ${prop.TestSubsystem}项目, 已完成${prop.K2NO}部署", 
                    // from: "FIVPServer@casco.com.cn",
                    // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}"
                // )
            }            
        }
        aborted {
            script{
                prop = readJSON file: "Jsonfor${index_str}.json"   
                DATE_TAG = java.time.LocalDate.now()
                TIME_TAG = java.time.LocalTime.now().withNano(0)    
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "login",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_CI_${timestamp}"   
                sleep 5

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmCI-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_CI_${timestamp} "
                sleep 2
                bat encoding: "UTF-8",label: "rmCI-F",  script: "if exist ${loc}_${index_str}_CI_${timestamp} rmdir /s /q ${loc}_${index_str}_CI_${timestamp} "
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmATS-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_ATS_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmATS-F",  script: "if exist ${loc}_${index_str}_ATS_${timestamp} rmdir /s /q ${loc}_${index_str}_ATS_${timestamp} "                    
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmATC-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_ATC_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmATC-F",  script: "if exist ${loc}_${index_str}_ATC_${timestamp} rmdir /s /q ${loc}_${index_str}_ATC_${timestamp} "      
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmDesign-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_DESIGN_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmDesign-F",  script: "if exist ${loc}_${index_str}_DESIGN_${timestamp} rmdir /s /q ${loc}_${index_str}_DESIGN_${timestamp} "         

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmSYDB-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_SYDB_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmSYDB-F",  script: "if exist ${loc}_${index_str}_SYDB_${timestamp} rmdir /s /q ${loc}_${index_str}_SYDB_${timestamp}"  
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmMSS-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_MSS_${timestamp} "
                sleep 2
                bat encoding: "UTF-8",label: "rmMSS-F",  script: "if exist ${loc}_${index_str}_MSS_${timestamp} rmdir /s /q ${loc}_${index_str}_MSS_${timestamp} "
                String endtime = java.time.LocalDateTime.now()
                bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----Process-----ABORTED-----${endtime}>>${logname}"
                // emailext (
                    // body: """
                        // <html>    
                            // <head>    
                                // <meta charset="UTF-8">    
                                // <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                            // </head>                          
                            // <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                // <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                    // <tr>    
                                        // 本邮件由系统自动发出，无需回复<br/>            
                                        // 以下为${prop.ProjectNumber}项目，对应K2单${prop.K2NO}的任务信息</br> 
                                        // <td><font color="#0B610B">任务结果 - \${BUILD_STATUS}</font></td>   
                                    // </tr>    
                                    // <tr>    
                                        // <td><br/>    
                                        // <b><font color="#0B610B">任务信息</font></b>    
                                        // <hr size="2" width="100%" align="center" /></td>    
                                    // </tr>    
                                    // <tr>    
                                        // <td>    
                                            // <ul>    
                                                // <li>项目名称 ： ${prop.ProjectNumber}</li>     
                                                // <li>发布单号 ： ${prop.K2NO}</li>
                                                // <li>测试类型 ： ${prop.TestSubsystem}</li>
                                                // <li>任务发起 ： ${prop.IPSource}</li>
                                                // <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>
                                                // <li>测试环境 ： \${PROJECT_NAME}</li>    
                                                // <li>触发原因 ： \${CAUSE}</li>    
                                                // <li>任务状态 ： \${BUILD_STATUS}</li>    
                                                // <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                // <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                // <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                // <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                // <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                         
                                            // </ul>         
                                        // </td>                                         
                                    // </tr>    
                                // </table>    
                            // </body>    
                        // </html>  
                    // """, 
                    // subject: "[系统自动发送][测试中断]${prop.IPSource}发起的${prop.ProjectNumber} ${prop.TestSubsystem}项目, 发布单号：${prop.K2NO}, 因超时中断部署", 
                    // from: "FIVPServer@casco.com.cn",
                    // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}"
                // )
            }
        }
        failure {
            script{
                prop = readJSON file: "Jsonfor${index_str}.json"   
                DATE_TAG = java.time.LocalDate.now()
                TIME_TAG = java.time.LocalTime.now().withNano(0)
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "login",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --ln -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_CI_${timestamp}"   
                sleep 5
                    
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmCI-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_CI_${timestamp} "
                sleep 2
                bat encoding: "UTF-8",label: "rmCI-F",  script: "if exist ${loc}_${index_str}_CI_${timestamp} rmdir /s /q ${loc}_${index_str}_CI_${timestamp} "
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmATS-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_ATS_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmATS-F",  script: "if exist ${loc}_${index_str}_ATS_${timestamp} rmdir /s /q ${loc}_${index_str}_ATS_${timestamp} "                    
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmATC-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_ATC_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmATC-F",  script: "if exist ${loc}_${index_str}_ATC_${timestamp} rmdir /s /q ${loc}_${index_str}_ATC_${timestamp} "      
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmDesign-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_DESIGN_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmDesign-F",  script: "if exist ${loc}_${index_str}_DESIGN_${timestamp} rmdir /s /q ${loc}_${index_str}_DESIGN_${timestamp} "         

                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmSYDB-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_SYDB_${timestamp} "   
                sleep 2
                bat encoding: "UTF-8",label: "rmSYDB-F",  script: "if exist ${loc}_${index_str}_SYDB_${timestamp} rmdir /s /q ${loc}_${index_str}_SYDB_${timestamp}"  
                
                timetime = Calendar.getInstance().getTimeInMillis();
                bat encoding: "UTF-8",label: "rmMSS-V",  script: "C:\\K2JEN\\tools\\CCUCM-1.exe --rm -t ${timetime} -u ${user} -p ${pass} -s ${prop.CCServer} -v ${loc}_${index_str}_MSS_${timestamp} "
                sleep 2
                bat encoding: "UTF-8",label: "rmMSS-F",  script: "if exist ${loc}_${index_str}_MSS_${timestamp} rmdir /s /q ${loc}_${index_str}_MSS_${timestamp} "
                String endtime = java.time.LocalDateTime.now()
                bat encoding: 'UTF-8',label: 'log',  script: "echo ${env.JOB_NAME}-----${env.BUILD_NUMBER}-----Process-----FAIL-----${endtime}>>${logname}"
                // emailext (
                    // body: """
                        // <html>    
                            // <head>    
                                // <meta charset="UTF-8">    
                                // <title>\${ENV, var="JOB_NAME"}-第\${BUILD_NUMBER}次构建日志</title>    
                            // </head>                          
                            // <body leftmargin="8" marginwidth="0" topmargin="8" marginheight="4" offset="0">    
                                // <table width="95%" cellpadding="0" cellspacing="0"  style="font-size: 11pt; font-family: Tahoma, Arial, Helvetica, sans-serif">    
                                    // <tr>    
                                        // 本邮件由系统自动发出，无需回复<br/>            
                                        // 以下为${prop.ProjectNumber}项目，对应K2单${prop.K2NO}的任务信息</br> 
                                        // <td><font color="#0B610B">任务结果 - \${BUILD_STATUS}</font></td>   
                                    // </tr>    
                                    // <tr>    
                                        // <td><br/>    
                                        // <b><font color="#0B610B">任务信息</font></b>    
                                        // <hr size="2" width="100%" align="center" /></td>    
                                    // </tr>    
                                    // <tr>    
                                        // <td>    
                                            // <ul>    
                                                // <li>项目名称 ： ${prop.ProjectNumber}</li>     
                                                // <li>发布单号 ： ${prop.K2NO}</li>
                                                // <li>测试类型 ： ${prop.TestSubsystem}</li>
                                                // <li>任务发起 ： ${prop.IPSource}</li>
                                                // <li>构建时间 ： ${DATE_TAG}, ${TIME_TAG}</li>
                                                // <li>测试环境 ： \${PROJECT_NAME}</li>    
                                                // <li>触发原因 ： \${CAUSE}</li>    
                                                // <li>任务状态 ： \${BUILD_STATUS}</li>    
                                                // <li>任务日志 ： <a href="\${BUILD_URL}console">\${BUILD_URL}console</a></li>    
                                                // <!-- <li>任务  Url ： <a href="\${BUILD_URL}">\${BUILD_URL}</a></li>     -->
                                                // <!-- <li>工作目录 ： <a href="\${PROJECT_URL}ws">\${PROJECT_URL}ws</a></li>     -->
                                                // <li>项目  Url ： <a href="\${PROJECT_URL}">\${PROJECT_URL}</a></li>    
                                                // <li><font color="#0B610B">点击URL可登陆系统查看任务进度统计和日志，用户名FIVP，密码FIVP</font></li>                       
                                            // </ul>         
                                        // </td>                                         
                                    // </tr>    
                                // </table>    
                            // </body>    
                        // </html>  
                    // """, 
                    // subject: "[系统自动发送][测试失败]${prop.IPSource}发起的${prop.ProjectNumber} ${prop.TestSubsystem}项目, 发布单号：${prop.K2NO}, 失败，请查看日志", 
                    // from: "FIVPServer@casco.com.cn",
                    // to: "${prop.Email[0]},${prop.Email[1]},${prop.Email[2]},${prop.VVEmail}"
                // )
            }
        }
    }
}
